LANDING PAGE UMKM NASI KUNING

Cara menggunakan:
1. Ekstrak file nasi_kuning_html.zip.
2. Buka folder hasil ekstrak.
3. Klik dua kali file index.html.
4. Website akan terbuka di browser seperti Google Chrome.

Untuk mengedit:
- Klik kanan index.html lalu buka dengan Visual Studio Code atau editor teks.
- Ubah teks, warna, atau informasi sesuai kebutuhan.

Kontak WhatsApp: 087733313097
Alamat: Siring RT 1 RW 1, Kenokorejo, Polokarto, Sukoharjo
